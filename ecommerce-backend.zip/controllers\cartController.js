const { Cart, Product } = require('../models');

// @desc    Get user cart
// @route   GET /api/cart
// @access  Private
exports.getCart = async (req, res) => {
  try {
    const cartItems = await Cart.findAll({
      where: { userId: req.user.id },
      include: [
        {
          model: Product,
          attributes: ['id', 'name', 'price', 'imageUrl', 'stock', 'discount']
        }
      ]
    });

    // Calculate cart totals
    let totalItems = 0;
    let totalPrice = 0;

    cartItems.forEach(item => {
      totalItems += item.quantity;
      const discountedPrice = item.Product.price * (1 - item.Product.discount / 100);
      totalPrice += discountedPrice * item.quantity;
    });

    res.json({
      success: true,
      cart: cartItems,
      totalItems,
      totalPrice: parseFloat(totalPrice.toFixed(2))
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// @desc    Add item to cart
// @route   POST /api/cart
// @access  Private
exports.addToCart = async (req, res) => {
  try {
    const { productId, quantity } = req.body;
    const userId = req.user.id;

    // Validate quantity
    if (!quantity || quantity <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Quantity must be greater than 0'
      });
    }

    // Check if product exists and has enough stock
    const product = await Product.findByPk(productId);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    if (product.stock < quantity) {
      return res.status(400).json({
        success: false,
        message: 'Not enough stock available'
      });
    }

    // Check if item already in cart
    let cartItem = await Cart.findOne({ where: { userId, productId } });

    if (cartItem) {
      // Update quantity if already in cart
      cartItem.quantity += quantity;
      await cartItem.save();
    } else {
      // Add new item to cart
      cartItem = await Cart.create({
        userId,
        productId,
        quantity
      });
    }

    // Return updated cart
    const updatedCart = await Cart.findAll({
      where: { userId },
      include: [
        {
          model: Product,
          attributes: ['id', 'name', 'price', 'imageUrl', 'stock', 'discount']
        }
      ]
    });

    res.status(201).json({
      success: true,
      cart: updatedCart,
      message: 'Item added to cart'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// @desc    Update cart item quantity
// @route   PUT /api/cart/:id
// @access  Private
exports.updateCartItem = async (req, res) => {
  try {
    const { quantity } = req.body;
    const cartItemId = req.params.id;
    const userId = req.user.id;

    // Validate quantity
    if (!quantity || quantity <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Quantity must be greater than 0'
      });
    }

    // Find cart item
    const cartItem = await Cart.findOne({
      where: { id: cartItemId, userId },
      include: [
        {
          model: Product,
          attributes: ['id', 'name', 'price', 'imageUrl', 'stock', 'discount']
        }
      ]
    });

    if (!cartItem) {
      return res.status(404).json({
        success: false,
        message: 'Cart item not found'
      });
    }

    // Check stock
    if (cartItem.Product.stock < quantity) {
      return res.status(400).json({
        success: false,
        message: 'Not enough stock available'
      });
    }

    // Update quantity
    cartItem.quantity = quantity;
    await cartItem.save();

    // Return updated cart
    const updatedCart = await Cart.findAll({
      where: { userId },
      include: [
        {
          model: Product,
          attributes: ['id', 'name', 'price', 'imageUrl', 'stock', 'discount']
        }
      ]
    });

    res.json({
      success: true,
      cart: updatedCart,
      message: 'Cart updated'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// @desc    Remove item from cart
// @route   DELETE /api/cart/:id
// @access  Private
exports.removeFromCart = async (req, res) => {
  try {
    const cartItemId = req.params.id;
    const userId = req.user.id;

    // Find cart item
    const cartItem = await Cart.findOne({
      where: { id: cartItemId, userId }
    });

    if (!cartItem) {
      return res.status(404).json({
        success: false,
        message: 'Cart item not found'
      });
    }

    // Remove item from cart
    await cartItem.destroy();

    // Return updated cart
    const updatedCart = await Cart.findAll({
      where: { userId },
      include: [
        {
          model: Product,
          attributes: ['id', 'name', 'price', 'imageUrl', 'stock', 'discount']
        }
      ]
    });

    res.json({
      success: true,
      cart: updatedCart,
      message: 'Item removed from cart'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// @desc    Clear cart
// @route   DELETE /api/cart
// @access  Private
exports.clearCart = async (req, res) => {
  try {
    const userId = req.user.id;

    // Remove all items from cart
    await Cart.destroy({
      where: { userId }
    });

    res.json({
      success: true,
      message: 'Cart cleared'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
}; 