const { Product, Category, Review, User } = require('../models');
const { Op } = require('sequelize');

// @desc    Get all products
// @route   GET /api/products
// @access  Public
exports.getProducts = async (req, res) => {
  try {
    const pageSize = 8;
    const page = Number(req.query.page) || 1;
    const category = req.query.category;
    const keyword = req.query.keyword;
    
    let whereClause = {};
    
    if (keyword) {
      whereClause.name = { [Op.like]: `%${keyword}%` };
    }
    
    if (category) {
      whereClause.categoryId = category;
    }
    
    const count = await Product.count({ where: whereClause });
    
    const products = await Product.findAll({
      where: whereClause,
      include: [
        { model: Category, attributes: ['id', 'name'] }
      ],
      limit: pageSize,
      offset: pageSize * (page - 1),
      order: [['createdAt', 'DESC']]
    });
    
    res.json({
      success: true,
      products,
      page,
      pages: Math.ceil(count / pageSize),
      count
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// @desc    Get single product
// @route   GET /api/products/:id
// @access  Public
exports.getProductById = async (req, res) => {
  try {
    const product = await Product.findByPk(req.params.id, {
      include: [
        { model: Category, attributes: ['id', 'name'] },
        { 
          model: Review,
          include: [
            { model: User, attributes: ['id', 'name'] }
          ]
        }
      ]
    });
    
    if (product) {
      res.json({
        success: true,
        product
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// @desc    Create a new product
// @route   POST /api/products
// @access  Private/Admin
exports.createProduct = async (req, res) => {
  try {
    const {
      name,
      price,
      description,
      imageUrl,
      countInStock,
      categoryId
    } = req.body;
    
    const product = await Product.create({
      name,
      price,
      description,
      imageUrl,
      countInStock,
      categoryId,
      rating: 0,
      numReviews: 0
    });
    
    res.status(201).json({
      success: true,
      product
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// @desc    Update a product
// @route   PUT /api/products/:id
// @access  Private/Admin
exports.updateProduct = async (req, res) => {
  try {
    const {
      name,
      price,
      description,
      imageUrl,
      countInStock,
      categoryId
    } = req.body;
    
    const product = await Product.findByPk(req.params.id);
    
    if (product) {
      product.name = name || product.name;
      product.price = price || product.price;
      product.description = description || product.description;
      product.imageUrl = imageUrl || product.imageUrl;
      product.countInStock = countInStock || product.countInStock;
      product.categoryId = categoryId || product.categoryId;
      
      const updatedProduct = await product.save();
      
      res.json({
        success: true,
        product: updatedProduct
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// @desc    Delete a product
// @route   DELETE /api/products/:id
// @access  Private/Admin
exports.deleteProduct = async (req, res) => {
  try {
    const product = await Product.findByPk(req.params.id);

    if (product) {
      // Soft delete: just mark as inactive
      product.isActive = false;
      await product.save();
      
      res.json({
        success: true,
        message: 'Product removed'
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// @desc    Create product review
// @route   POST /api/products/:id/reviews
// @access  Private
exports.createProductReview = async (req, res) => {
  try {
    const { rating, title, comment } = req.body;
    const productId = req.params.id;
    const userId = req.user.id;

    // Check if product exists
    const product = await Product.findByPk(productId);
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    // Check if user already reviewed this product
    const alreadyReviewed = await Review.findOne({
      where: {
        userId,
        productId
      }
    });

    if (alreadyReviewed) {
      return res.status(400).json({
        success: false,
        message: 'Product already reviewed'
      });
    }

    // Create review
    const review = await Review.create({
      userId,
      productId,
      rating: Number(rating),
      title,
      comment
    });

    // Update product ratings
    const reviews = await Review.findAll({ where: { productId } });
    const totalRating = reviews.reduce((sum, item) => sum + item.rating, 0);
    
    product.rating = totalRating / reviews.length;
    product.numReviews = reviews.length;
    
    await product.save();

    res.status(201).json({
      success: true,
      review,
      message: 'Review added'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
}; 