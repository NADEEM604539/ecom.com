const { Category, Product } = require('../models');

// @desc    Get all categories
// @route   GET /api/categories
// @access  Public
exports.getCategories = async (req, res) => {
  try {
    const categories = await Category.findAll({
      where: { isActive: true },
      order: [['name', 'ASC']]
    });

    res.json({
      success: true,
      categories
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// @desc    Get category by ID
// @route   GET /api/categories/:id
// @access  Public
exports.getCategoryById = async (req, res) => {
  try {
    const category = await Category.findByPk(req.params.id, {
      include: [
        {
          model: Product,
          where: { isActive: true },
          required: false
        }
      ]
    });

    if (category) {
      res.json({
        success: true,
        category
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'Category not found'
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// @desc    Create a category
// @route   POST /api/categories
// @access  Private/Admin
exports.createCategory = async (req, res) => {
  try {
    const { name, description, imageUrl } = req.body;

    // Check if category already exists
    const categoryExists = await Category.findOne({ where: { name } });

    if (categoryExists) {
      return res.status(400).json({
        success: false,
        message: 'Category already exists'
      });
    }

    const category = await Category.create({
      name,
      description,
      imageUrl
    });

    if (category) {
      res.status(201).json({
        success: true,
        category
      });
    } else {
      res.status(400).json({
        success: false,
        message: 'Invalid category data'
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// @desc    Update a category
// @route   PUT /api/categories/:id
// @access  Private/Admin
exports.updateCategory = async (req, res) => {
  try {
    const { name, description, imageUrl } = req.body;
    const category = await Category.findByPk(req.params.id);

    if (category) {
      category.name = name || category.name;
      category.description = description || category.description;
      category.imageUrl = imageUrl || category.imageUrl;

      const updatedCategory = await category.save();
      res.json({
        success: true,
        category: updatedCategory
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'Category not found'
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
};

// @desc    Delete a category
// @route   DELETE /api/categories/:id
// @access  Private/Admin
exports.deleteCategory = async (req, res) => {
  try {
    const category = await Category.findByPk(req.params.id);

    if (category) {
      // Soft delete: just mark as inactive
      category.isActive = false;
      await category.save();
      
      res.json({
        success: true,
        message: 'Category removed'
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'Category not found'
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server Error'
    });
  }
}; 